#Part 03
#I declare that my work contains no examples of misconduct,such as plagaiarism,or collusion.
#Any code taken from other sources is referenced within my code solution.
#NAME : HUMPITA PATHIRANNEHELAGE JEVIN WISHWA KUMARA JAYAWARDHANA
#IIT ID : 20222201                   #UoW ID : W1985552

progress = 0 #progress count
trailer = 0 #module trailer count
retriever = 0 #module retriever count
exclude = 0 #exclude count
total = 0 # Total of above 4 count
List2 = '' #This is the option key to continue or quit.
marklist_for_part3 = [] #this list belongs to part3 
Valid_score = [0, 20, 40, 60, 80, 100, 120]

def credit_to_the_Pass():
    while True:
        try:
            global Pass
            Pass = int(input("Enter your credits at Pass: "))
            if Pass in Valid_score:
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-") #check whether score is out of range
        except ValueError:
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")  # If user entered a string as a valid mark, this will gives "-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-" as the output.


def credit_to_the_Defer():
    while True:
        try:
            global Defer
            Defer = int(input("Enter your credit at Defer: "))
            if Defer in Valid_score:
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")
        except ValueError:
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")

def credit_to_the_Fail():
    while True:
        try:
            global Fail
            Fail = int(input("Enter your credit at Fail: "))
            if Fail in Valid_score:
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")
        except ValueError:
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")

while List2 != 'q':
    while True:
        credit_to_the_Pass()
        credit_to_the_Defer()
        credit_to_the_Fail()

        Total = Pass + Defer + Fail
        if Total == 120:
            break
        else:
            print("Total Incorrect")

    total_count = progress + trailer + retriever + exclude
    if Pass == 120:
        print("Progress")
        progress += 1
        marklist_for_part3.append(["Progress -", Pass, Defer, Fail])

    elif Pass == 100:
        print("PRogress (module retriever)")
        trailer += 1
        marklist_for_part3.append(["Progress (module trailer) -", Pass, Defer, Fail])

    elif Fail <= 60:
        print("Module retriever")
        retriever += 1
        marklist_for_part3.append(["Module retriever -", Pass, Defer, Fail])

        total = progress + trailer + retriever + exclude

    while True:
        List2 = input("-----WOULD YOU LIKE ENTER ANOTHER DATA SET?----- \n         ENTER 'y' FOR YES OR 'q' TO QUIT AND VIEW RESULTS: \n")
        List2 = List2.lower()

        print(" ")
        if List2 == 'y' or List2 == 'q':
            break
        else:
            print("Please enter 'y' or 'q'")

    print("-"*90)
    print(" ")

def Textfile():
    with open ("jevz.txt","w") as File_name:  # saving file as text file
        for factor in marklist_for_part3:
            print(f'{factor[0]} {factor[1]}, {factor[2]}, {factor[3]}', file = File_name)
        print()
    with open ("jevz.txt","r") as File_name:  # Reading entire file
        print(File_name.read())

Textfile() #calling function that save a list of progression outcomes to text file 

        
































            
            
    
