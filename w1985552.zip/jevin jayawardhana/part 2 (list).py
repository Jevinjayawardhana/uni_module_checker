#part 02 (list)
#I declare that my work contains no examples of misconduct,such as plagaiarism,or collusion.
#Any code taken from other sources is referenced within my code solution.
#NAME : HUMPITA PATHIRANNEHELAGE JEVIN WISHWA KUMARA JAYAWARDHANA
#IIT ID : 20222201                   #UoW ID : W1985552


progress = 0  # Progress Count
trailer = 0  # Module Trailer Count
retriever = 0  # Module Retriever Count
exclude = 0  # Excluded Count
total=0 # Total of above 4 counts
List2 = ''  # This is the option key to continue or quit.
marklist_for_part3 = []  # This list belongs to part 3(List/Tuple/Directory)
valid_score = [0, 20, 40, 60, 80, 100, 120]


def Credits_to_the_Pass():
    while True:
        try:
            global Pass
            Pass = int(input("Enter your credits at Pass: "))  # Get Credits at Pass
            if Pass in valid_score:  # Check whether Pass is out of range
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")

        except ValueError:  # If we entered a string as a valid mark, this will gives "Integer required" as the output.
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")


def Credits_to_the_Defer():
    while True:
        try:
            global Defer
            Defer = int(input("Enter your credits at defer: "))  # Get Credits at Defer
            if Defer in valid_score: # Check whether Fail is out of range
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")

        except ValueError:  # If we entered a string as a valid mark, this will gives "Integer required" as the output.
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")


def Credits_to_the_Fail():
    while True:
        try:
            global Fail
            Fail = int(input("Enter your credits at fail: "))  # Get Credits at Fail
            if Fail in valid_score: # Check whether Defer is out of range
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")

        except ValueError: # If we entered a string as a valid mark, this will gives "Integer required" as the output.
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")


while List2 != 'q':
    while True:
        Credits_to_the_Pass()   # Calling function credits at pass
        Credits_to_the_Defer()  # Calling function credits at defer
        Credits_to_the_Fail()   # Calling function credits at fail


        Total = Pass + Defer + Fail
        if Total == 120:
            break
        else:
            print("Total incorrrect")
    
    if Pass == 120:
        print("Progress")
        progress += 1
        marklist_for_part3.append(["Progress -", Pass, Defer, Fail])

    elif Pass == 100:
        print("Progress (module trailer)")
        trailer += 1
        marklist_for_part3.append(["Progress (module trailer) -", Pass, Defer, Fail])

    elif Fail <= 60:
        print("Module retriever")
        retriever += 1
        marklist_for_part3.append(["Module retriever -", Pass, Defer, Fail])

    elif Fail > 60:
        print("Exclude")
        exclude += 1
        marklist_for_part3.append(["Exclude –", Pass, Defer, Fail])

    total = progress + trailer + retriever + exclude

    print(" ")
    
    while True:
        List2 = input("WOULD YOU LIKE TO ENTER ANOTHER SET OF DATA? \n ENTER 'y' FOR YES OR 'q' TO QUIT AND VIEW RESULTS:")
        List2 = List2.lower()
        print(" ")
        if List2 == 'y' or List2 == 'q':
            break

        else:
            print("Please enter 'y' or 'q'")

    print("-" * 90)
    print(" ")

 # -----------------------------------PART 3 -  List/Tuple/Directory (extension) -----------------------------------
def elementlist():
    for factor in marklist_for_part3:
        print(f'{factor[0]} {factor[1]}, {factor[2]}, {factor[3]}')
    print()


elementlist()  # Calling function that makes a list of progression outcomes
