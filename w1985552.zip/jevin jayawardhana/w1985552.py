#PART 01 (main version)
#I declare that my work contains no examples of misconduct,such as plagaiarism,or collusion.
#Any code taken from other sources is referenced within my code solution.
#NAME : HUMPITA PATHIRANNEHELAGE JEVIN WISHWA KUMARA JAYAWARDHANA
#IIT NO : 20222201                   #UoW NO : W1985552
#1ST YEAR 1 ST SEM COURSE WORK 01
#MODULE : SOFTWARE DEVELOPING



progress = 0  # Progress Count
trailer = 0  # Module Trailer Count
retriever = 0  # Module Retriever Count
exclude = 0  # Excluded Count
total=0
List2 = ''  # This is the option key to continue or quit.
List1 = 0  # This is the first option key to what would you choose either Student Version or Staff Version.
valid_score = [0, 20, 40, 60, 80, 100, 120]


def credits_to_the_Pass():
    while True:
        try:
            global Pass
            Pass = int(input("Enter your credits at Pass: "))  # Get Credits at Pass
            if Pass in valid_score:  # Check whether Pass is out of range
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")

        except ValueError:  # If we entered a string as a valid mark, this will gives "Integer required" as the output.
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")


def credits_to_the_Defer():
    while True:
        try:
            global Defer
            Defer = int(input("Enter your credits at Defer: "))  # Get Credits at Defer
            if Defer in valid_score:
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")# Check whether Fail is out of range

        except ValueError:  # If we entered a string as a valid mark, this will gives "Integer required" as the output.
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")


def credits_to_the_Fail():
    while True:
        try:
            global Fail
            Fail = int(input("Enter your credits at Fail: "))  # Get Credits at Fail
            if Fail in valid_score: # Check whether Defer is out of range
                break
            else:
                print("-O-U-T--O-F--R-A-N-G-E-")

        except ValueError:  # If we entered a string as a valid mark, this will gives "Integer required" as the output.
            print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")


def Horizontal():
    print("--------------------Horizontal Histogram--------------------")
    print(" ")
    print('Progress         ', progress, '   : ', '*' * progress)
    print('Trailer          ', trailer, '   : ', '*' * trailer)
    print('Retriever        ', retriever, '   : ', '*' * retriever)
    print('Excluded         ', exclude, '   : ', '*' * exclude)
    print(" ")

    global total
    total = progress + trailer + retriever + exclude
    print(total, " outcomes in total")



while True:
    
    List1 = int(input("ENTER NUMBER 1 FOR STUDENT VERSION:\n      NUMBER 2 FOR STAFF VERSION: \n"))

    if List1 == 1 or List1 == 2:
        break
    else:
        print("ENTER '1' or '2' ")



if List1 == 1:
    print("####################-YOU CHOOSE OPTION 1-#################### \n--------------------WELCOME TO STUDENT VERSION-------------------- \n")
    print(" ")
    while True:
        
        credits_to_the_Pass()  #Calling function credits at pass
        credits_to_the_Defer() #Calling function credits at defer
        credits_to_the_Fail()  #Calling function credits at fail
        Total = Pass + Defer + Fail
        if Total == 120:
            break
        else:
            print("Total Incorrrect")
    
        
    if Pass == 120:
        print("Progress")
        progress += 1

    elif Pass == 100:
        print("Progress (module trailer)")
        trailer += 1

    elif Fail <= 60:
        print("Module retriever")
        retriever += 1

    elif Fail > 60:
        print("Exclude")
        exclude += 1
    print("------------------------Thank you---------------------------")    


if List1 == 2:
    print("####################-YOU CHOOSE OPTION 2-#################### \n--------------------WELCOME TO STAFF VERSION-------------------- \n")
    print(" ")
    while List2 != 'q':
        while True:
            credits_to_the_Pass()  #Calling function credits at pass
            credits_to_the_Defer() #Calling function credits at defer
            credits_to_the_Fail()  #Calling function credits at fail

            Total = Pass + Defer + Fail
            if Total == 120:
                break
            else:
                print("Total Incorrrect")
        if Pass == 120:
            print("Progress")
            progress += 1

        elif Pass == 100:
            print("Progress (Module Trailer)")
            trailer += 1

        elif Fail <= 60:
            print("Module Retriever")
            retriever += 1

        elif Fail > 60:
            print("Exclude")
            exclude += 1

        while True:
            print(" ")
            List2 = input("WOULD YOU LIKE TO ENTER ANOTHER SET OF DATA? \n ENTER 'y' FOR YES OR 'q' TO QUIT AND VIEW RESULTS:")
            Lits2 = List2.lower()
            print(" ")
            if List2 == 'y' or List2 == 'q':
                break

            else:
                print("Please enter 'y' or 'q'")

    Horizontal() #Calling Function that gives us Horizontal Histogram
