# part 04 (Dictionary)
# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion.
# Any code taken from other sources is referenced within my code solution.
# NAME : HUMPITA PATHIRANNEHELAGE JEVIN WISHWA KUMARA JAYAWARDHANA
# IIT ID : 20222201                   # UoW ID : W1985552

valid_score = [0, 20, 40, 60, 80, 100, 120]
progress = {}
trailer = {}
retriever = {}
exclude = {}

while True:
    userid = input("Please enter your userid (or 'q' to quit): ")
    if userid == "q":
        break
    
    lower_userid = userid.lower()

    try:
        Pass = ''
        while Pass not in valid_score:
            Pass = int(input("Enter your credits at Pass: "))
            if Pass not in valid_score:
                print("-O-U-T--O-F--R-A-N-G-E-")
    except ValueError:
        print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")
        continue
        
    try:
        Defer = ''
        while Defer not in valid_score:
            Defer = int(input("Enter your credits at defer: "))
            if Defer not in valid_score:
                print("-O-U-T--O-F--R-A-N-G-E-")
    except ValueError:
        print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")
        continue
                
    try:
        Fail = ''
        while Fail not in valid_score:
            Fail = int(input("Enter your credits at fail: "))
            if Fail not in valid_score:
                print("-O-U-T--O-F--R-A-N-G-E-.")
    except ValueError:
        print("-I-N-T-E-G-E-R--R-E-Q-U-I-R-E-D-")
        continue

    Total = Pass + Defer + Fail
        
    if Total != 120:
        print("Total incorrect")
        continue

    if Pass == 120:
        progress[lower_userid] = "Progress"
    elif Pass == 100:
        trailer[lower_userid] = "Progress (module trailer)"
    elif Fail <= 60:
        retriever[lower_userid] = "Module retriever"
    elif Fail > 60:
        exclude[lower_userid] = "Exclude"


print("\nOutcome of each student:")
for key, value in progress.items():
    print(f"{key}: {value} - 120, 0, 0")

for key, value in trailer.items():
    print(f"{key}: {value} - 100, 0, 20")
    
for key, value in retriever.items():
    print(f"{key}: {value} - 80, 20, 20")

for key, value in exclude.items():
    print(f"{key}: {value} - 40, 0, 80")



